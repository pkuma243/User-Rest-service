package com.pk.rest.user.crud;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;



import org.springframework.stereotype.Component;

@Component
public class UserDaoService {
	private static List<User> users =new ArrayList<>();
	private static int userCount=2;
	static {
		users.add(new User(1,"Rakesh",new Date()));
		users.add(new User(2,"Priyendu",new Date()));
		}

	public List<User> getAllUser() {
		
		return users;
	}

	public User saveUser(User user) {
		if(user.getId()==null) {
			user.setId(++userCount);
		}
		users.add(user);
		return user;
	}
	public User findOne(int id) {
		for (User user : users) {
			if (user.getId() == id) {
				return user;
			}
		}
		return null;
	}
	public User deleteUser(int id) {
		Iterator<User> itetator=users.iterator();
		while(itetator.hasNext()) {
			User user=itetator.next();
			if(user.getId()==id) {
				itetator.remove();
				return user;
			}
		}
		return null;
	}

}
