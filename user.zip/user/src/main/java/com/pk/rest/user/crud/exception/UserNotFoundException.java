package com.pk.rest.user.crud.exception;

public class UserNotFoundException extends RuntimeException{
	public UserNotFoundException(String message) {
		super();
	}

}
