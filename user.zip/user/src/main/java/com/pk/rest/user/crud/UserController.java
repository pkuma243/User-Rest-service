package com.pk.rest.user.crud;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.hateoas.Resource;
import org.springframework.hateoas.mvc.ControllerLinkBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.pk.rest.user.crud.User;
import com.pk.rest.user.crud.exception.UserNotFoundException;




@RestController
public class UserController {
	@Autowired
	private MessageSource messageSource; 
	
	@Autowired
	private UserDaoService userDaoService;
	
	@GetMapping(path="/users")
	public List<User> getAllUser(){
		return userDaoService.getAllUser();
	}
	
	@GetMapping("/user/{id}")
	public Resource<User> retrieveUser(@PathVariable int id) {
		User user = userDaoService.findOne(id);
		if(user == null)
			throw new UserNotFoundException("User not found with Id :" +id);
		Resource<User> resource = new Resource<User>(user);
		
		ControllerLinkBuilder linkTo = 
				linkTo(methodOn(this.getClass()).getAllUser());
		
		resource.add(linkTo.withRel("all-users"));
		return resource;
	}
	
	@PostMapping("/users")
	public ResponseEntity<Object> createUser(@Valid @RequestBody User user){
		User saveduser=userDaoService.saveUser(user);
		return ResponseEntity.ok("user has been created sucessfully with Id: "+user.getId());
	}
	
	@DeleteMapping("/users/{id}")
	public ResponseEntity<Object> deleteUser(@PathVariable int id) {
		User user= userDaoService.deleteUser(id);
		return ResponseEntity.ok("User has been deleted successfully with Id:"+user.getId());
		
	}
	
	
	
	
	@GetMapping(path="/hello-world")
	public String helloWorld() {
		return "Hello-World";
	}
	@GetMapping(path="/hello-world-bean")
	public HelloWorldBean helloWorldBean() {
		return new HelloWorldBean("hello-Rakeshh");
	}
	@GetMapping(path="/hello/path-variable/{name}")
	public HelloWorldBean helloWorldpathvariable(@PathVariable String name) {
		return new HelloWorldBean(String.format("Hello World, %s", name)); 
	}
	

	@GetMapping(path = "/hello-world-internationalized")
	public String helloWorldInternationalized() {
		return messageSource.getMessage("good.morning.message", null, 
									LocaleContextHolder.getLocale());
}
	
}
